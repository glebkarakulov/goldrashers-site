(() => {
  'use strict';

  const archive = document.querySelector('[data-matches-archive]');
  if (!archive) return;

  const matches = [
    { date: '2026-08-28', label: '28 августа 2026', opponent: 'Banger Gang', home: 7, away: 13, result: 'loss', maps: 'Dust2', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'banger-gang-result-logo.png' },
    { date: '2026-08-27', label: '27 августа 2026', opponent: 'EvolupeGG', home: 13, away: 4, result: 'win', maps: 'Ancient', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'evolupegg-logo.png' },
    { date: '2026-08-26', label: '26 августа 2026', opponent: 'A Great Chaos', home: 1, away: 0, result: 'win', maps: '', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'agreatchaos-result-logo.png' },
    { date: '2026-08-21', label: '21 августа 2026', opponent: 'Sangal', home: 13, away: 11, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'sangal-logo.png' },
    { date: '2026-08-21', label: '21 августа 2026', opponent: 'ZOTIX', home: 9, away: 13, result: 'loss', maps: 'Ancient', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'ZOTIX.PNG' },
    { date: '2026-08-20', label: '20 августа 2026', opponent: 'TSA Green', home: 1, away: 13, result: 'loss', maps: 'Dust2', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'tsa-green-logo.png' },
    { date: '2026-08-19', label: '19 августа 2026', opponent: 'NAVI Junior', home: 9, away: 13, result: 'loss', maps: 'Mirage', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'navi-junior.PNG' },
    { date: '2026-08-18', label: '18 августа 2026', opponent: 'Fortress', home: 10, away: 13, result: 'loss', maps: 'Ancient', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'fortress-logo.png', tile: true },
    { date: '2026-08-16', label: '16 августа 2026', opponent: 'MAYAK Arena', home: 2, away: 0, result: 'win', maps: 'Dust2 · Mirage', format: 'BO3', tournament: 'CyberClash Open · Qualifier 2 · Финал', logo: 'mayak-arena-logo.png' },
    { date: '2026-08-16', label: '16 августа 2026', opponent: 'golovastiki', home: 13, away: 7, result: 'win', maps: 'Mirage', format: 'BO1', tournament: 'CyberClash Open · Qualifier 2 · 1/2', logo: 'golovastiki-logo.png', tile: true },
    { date: '2026-08-16', label: '16 августа 2026', opponent: 'Swaga', home: 13, away: 3, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'CyberClash Open · Qualifier 2 · 1/4', logo: 'swaga-logo.png', tile: true },
    { date: '2026-08-16', label: '16 августа 2026', opponent: '4Z', home: 13, away: 5, result: 'win', maps: 'Ancient', format: 'BO1', tournament: 'CyberClash Open · Qualifier 2 · 1/8', logo: '4z-logo.png', tile: true },
    { date: '2026-08-16', label: '16 августа 2026', opponent: 'GameSport', home: 13, away: 11, result: 'win', maps: 'Mirage', format: 'BO1', tournament: 'CyberClash Open · Qualifier 2 · 1/16', logo: 'gamesport-logo.png' },
    { date: '2026-08-12', label: '12 августа 2026', opponent: 'PURE', home: 13, away: 9, result: 'win', maps: 'Mirage', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'pure-logo.png' },
    { date: '2026-08-12', label: '12 августа 2026', opponent: 'eSuba', home: 7, away: 13, result: 'loss', maps: 'Dust2', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'esuba-logo.png' },
    { date: '2026-08-10', label: '10 августа 2026', opponent: 'Banda Chuya', home: 4, away: 13, result: 'loss', maps: 'Ancient', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'banda-chuya-logo.png' },
    { date: '2026-08-07', label: '7 августа 2026', opponent: 'XI Esport', home: 11, away: 13, result: 'loss', maps: 'Ancient', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'xi-esport-logo.png' },
    { date: '2026-07-19', label: '19 июля 2026', opponent: 'OGZXCGBC', home: 2, away: 0, result: 'win', maps: 'Dust2 · Mirage', format: 'BO3', tournament: 'Лига Будущего 2 · Финал', logo: 'ogzxcgbc-logo.png' },
    { date: '2026-07-19', label: '19 июля 2026', opponent: '3Nation', home: 13, away: 11, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'Лига Будущего 2 · Плей-офф · 1/2', logo: '3nation-logo.png' },
    { date: '2026-07-19', label: '19 июля 2026', opponent: 'BezNegativa', home: 13, away: 8, result: 'win', maps: 'Mirage', format: 'BO1', tournament: 'Лига Будущего 2 · Плей-офф · 1/4', logo: 'beznegativa-logo.png' },
    { date: '2026-07-18', label: '18 июля 2026', opponent: 'Extension', home: 13, away: 0, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'Лига Будущего 2 · Групповой этап', logo: 'extension-logo.png' },
    { date: '2026-07-18', label: '18 июля 2026', opponent: 'LGD', home: 13, away: 3, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'Лига Будущего 2 · Групповой этап', logo: 'lgd-logo.png' },
    { date: '2026-07-18', label: '18 июля 2026', opponent: '2miracl', home: 13, away: 5, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'Лига Будущего 2 · Групповой этап', logo: '2miracl-logo.png' },
    { date: '2026-07-17', label: '17 июля 2026', opponent: 'gothboiclique', home: 13, away: 9, result: 'win', maps: 'Dust2', format: 'BO1', tournament: 'ESEA Advanced S58', logo: 'gothboiclique-logo.png', tile: true }
  ];

  const getLanguage = () => window.GoldRashersI18n?.language === 'en' ? 'en' : 'ru';
  const formatDate = (date) => {
    const value = new Date(`${date}T12:00:00`);
    if (getLanguage() === 'en') {
      return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }).format(value);
    }
    return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }).format(value).replace(' г.', '');
  };
  const formatTournament = (tournament) => getLanguage() === 'en'
    ? tournament
      .replace('Лига Будущего 2', 'League of the Future 2')
      .replace('Групповой этап', 'Group Stage')
      .replace('Плей-офф', 'Playoffs')
      .replace('Финал', 'Final')
    : tournament;

  const renderMatches = () => {
    const wins = matches.filter((match) => match.result === 'win').length;
    const losses = matches.length - wins;
    document.querySelector('[data-match-total]').textContent = String(matches.length);
    document.querySelector('[data-match-wins]').textContent = String(wins);
    document.querySelector('[data-match-losses]').textContent = String(losses);

    const isEnglish = getLanguage() === 'en';
    archive.innerHTML = matches.map((match) => {
      const homeWon = match.result === 'win';
      const resultText = homeWon ? (isEnglish ? 'Win' : 'Победа') : (isEnglish ? 'Loss' : 'Поражение');
      const mapText = match.maps || match.format;
      const footerText = match.maps ? `${match.format} · ${match.maps}` : match.format;
      const scoreLabel = isEnglish ? `Score ${match.home}:${match.away}` : `Счёт ${match.home}:${match.away}`;
      return `
      <article class="match-card match-${match.result}">
        <div class="match-meta">
          <div><span class="match-state">${isEnglish ? 'Completed' : 'Завершён'}</span><time datetime="${match.date}">${formatDate(match.date)}</time></div>
          <span class="tournament">${formatTournament(match.tournament)}</span>
        </div>
        <div class="match-teams">
          <div class="match-team team-home"><img src="assets/images/goldrashers-mark.png" alt="GoldRashers" width="92" height="92"><strong>GoldRashers</strong></div>
          <div class="match-score" aria-label="${scoreLabel}"><span class="${homeWon ? 'winner-score' : ''}">${match.home}</span><i>:</i><span class="${homeWon ? '' : 'winner-score'}">${match.away}</span><small>${mapText}</small></div>
          <div class="match-team team-away"><img class="${match.tile ? 'logo-tile' : ''}" src="assets/images/${match.logo}" alt="${match.opponent}" width="92" height="92"><strong>${match.opponent}</strong></div>
        </div>
        <div class="match-footer"><span class="result-pill result-${match.result}">${resultText}</span><span>${footerText}</span></div>
      </article>`;
    }).join('');
  };

  renderMatches();
  document.addEventListener('goldrashers:languagechange', renderMatches);
})();
