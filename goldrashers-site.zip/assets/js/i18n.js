(() => {
  'use strict';

  const STORAGE_KEY = 'goldrashers-language';
  const DEFAULT_LANGUAGE = 'ru';
  const translations = {
    'GoldRashers — киберспортивная организация по Counter-Strike 2. Состав, матчи, достижения, новости и официальные социальные сети клуба.': 'GoldRashers is a Counter-Strike 2 esports organization. Roster, matches, achievements, news, and official club social links.',
    'GoldRashers, esports, CS2, Counter-Strike 2, киберспорт': 'GoldRashers, esports, CS2, Counter-Strike 2',
    'GoldRashers — киберспортивная организация': 'GoldRashers — esports organization',
    'Официальный сайт GoldRashers: команда, матчи, достижения, новости и клубная экосистема.': 'The official GoldRashers website: team, matches, achievements, news, and club ecosystem.',
    'Перейти к содержимому': 'Skip to content',
    'Выбор языка': 'Language selector',
    'Русский язык': 'Russian language',
    'Английский язык': 'English language',
    'GoldRashers — на главную': 'GoldRashers — home',
    'Главная навигация': 'Primary navigation',
    'Мобильная навигация': 'Mobile navigation',
    'Открыть меню': 'Open menu',
    'Закрыть меню': 'Close menu',
    'Матчи': 'Matches',
    'матчи': 'matches',
    'Команда': 'Team',
    'Достижения': 'Achievements',
    'Новости': 'News',
    'новости': 'news',
    'О клубе': 'About',
    'Партнёры': 'Partners',
    'Магазин': 'Shop',
    'Созданы': 'Built',
    'чтобы': 'to',
    'идти напролом.': 'break through.',
    'GoldRashers — быстрорастущая организация, развивающая профессиональную CS2-команду, контент, сообщество и собственную экосистему вокруг киберспорта.': 'GoldRashers is a fast-growing organization developing a professional CS2 team, content, community, and its own esports ecosystem.',
    'Смотреть состав': 'View roster',
    'Последние матчи': 'Latest matches',
    'Ключевые показатели клуба': 'Club highlights',
    'Основан': 'Founded',
    'Май 2026': 'May 2026',
    'Состав': 'Roster',
    'игроков': 'players',
    'Призовые': 'Prize money',
    'Логотип GoldRashers': 'GoldRashers logo',
    'Следующий большой этап': 'Next major stage',
    '5 октября': '5 October',
    'Предстоящие матчи и последние результаты GoldRashers': 'Upcoming matches and the latest GoldRashers results.',
    'Предстоящий': 'Upcoming',
    'Предстоящий матч': 'Upcoming match',
    'Завершён': 'Completed',
    'Победа': 'Win',
    'Поражение': 'Loss',
    'Счёт 9:13': 'Score 9:13',
    '25 августа 2026 · 20:00': '25 August 2026 · 20:00',
    '27 августа 2026 · 21:30': '27 August 2026 · 21:30',
    '19 августа 2026': '19 August 2026',
    '21 августа 2026': '21 August 2026',
    'Все матчи': 'All matches',
    'Все': 'All',
    'Основной': 'Main',
    'состав': 'roster',
    'Пять игроков, единая игровая система и команда, которая развивает GoldRashers за пределами сервера.': 'Five players, one game plan, and a team growing GoldRashers beyond the server.',
    'Игрок GoldRashers в клубной форме': 'GoldRashers player in team jersey',
    'Анар Агамалов': 'Anar Agamalov',
    'Тимур Колотилин': 'Timur Kolotilin',
    'Илья Белозеров': 'Ilya Belozerov',
    'Вячеслав Моисеев': 'Vyacheslav Moiseev',
    'Егор Поляниченко': 'Egor Polyanichenko',
    'Анар': 'Anar',
    'Агамалов': 'Agamalov',
    'Илья': 'Ilya',
    'Белозеров': 'Belozerov',
    'Вячеслав': 'Vyacheslav',
    'Моисеев': 'Moiseev',
    'Карим': 'Karim',
    'Шельгорн': 'Shelgorn',
    'Егор': 'Egor',
    'Поляниченко': 'Polyanichenko',
    'Открыть профиль z0nger на FACEIT': 'Open z0nger’s FACEIT profile',
    'Открыть профиль akaza7331 на FACEIT': 'Open akaza7331’s FACEIT profile',
    'Открыть профиль thsleepphase на FACEIT': 'Open thsleepphase’s FACEIT profile',
    'Открыть профиль nightst4r на FACEIT': 'Open nightst4r’s FACEIT profile',
    'Руководство': 'Management',
    'и медиа': '& media',
    'ГК': 'GK',
    'КС': 'KS',
    'МР': 'MR',
    'ПК': 'PK',
    'Глеб Каракулов': 'Gleb Karakulov',
    'Основатель и CEO': 'Founder & CEO',
    'Глеб Каракулов — основатель киберспортивной организации GoldRashers.': 'Gleb Karakulov is the founder of the GoldRashers esports organization.',
    'Социальные сети Глеба Каракулова': 'Gleb Karakulov’s social links',
    'Telegram Глеба Каракулова': 'Gleb Karakulov on Telegram',
    'Кирилл Соловьев': 'Kirill Solovyov',
    'Комментатор': 'Commentator',
    'Кирилл «sshambei» Соловьев — тот самый голос, который сопровождает наши матчи.': 'Kirill “sshambei” Solovyov is the voice that carries our matches.',
    'Социальные сети Кирилла Соловьева': 'Kirill Solovyov’s social links',
    'Telegram Кирилла Соловьева': 'Kirill Solovyov on Telegram',
    'Максим Рыбаков': 'Maksim Rybakov',
    'Дизайнер': 'Designer',
    'Максим «Tsakuro» Рыбаков — создатель визуала GoldRashers.': 'Maksim “Tsakuro” Rybakov creates the GoldRashers visual identity.',
    'Социальные сети Максима Рыбакова': 'Maksim Rybakov’s social links',
    'Telegram Максима Рыбакова': 'Maksim Rybakov on Telegram',
    'Прохор Коморный': 'Prokhor Komorny',
    'SMM-менеджер': 'SMM manager',
    'Прохор «nepal» Коморный — человек, который отвечает за соцсети и стоит за каждым постом GoldRashers.': 'Prokhor “nepal” Komorny runs social media and is behind every GoldRashers post.',
    'Социальные сети Прохора Коморного': 'Prokhor Komorny’s social links',
    'Telegram Прохора Коморного': 'Prokhor Komorny on Telegram',
    'Общее количество выигранных призовых': 'Total prize money won',
    'Список достижений': 'Achievements list',
    'Кубок': 'Trophy',
    'Чемпионы': 'Champions',
    'Лига Будущего 2': 'League of the Future 2',
    '19 июля 2026 года': '19 July 2026',
    '19 июля 2026': '19 July 2026',
    'Состав чемпионов': 'Championship roster',
    'Открыть чемпионский состав Лиги Будущего 2': 'Open the League of the Future 2 champions roster',
    'Закрыть состав чемпионов': 'Close champions roster',
    'Победный состав': 'Winning roster',
    'Состав GoldRashers, который выиграл турнир 19 июля 2026 года.': 'The GoldRashers roster that won the tournament on 19 July 2026.',
    'В центре': 'At the heart',
    'событий': 'of the action',
    'Главные новости команды, турнирные анонсы и результаты.': 'Team headlines, tournament announcements, and results.',
    'Последние новости': 'Latest news',
    'Турнир': 'Tournament',
    'Сообщество': 'Community',
    'Медиа': 'Media',
    'GoldRashers в основной стадии CyberClash Open': 'GoldRashers reach the CyberClash Open main stage',
    'GoldRashers в основной стадии': 'GoldRashers reach the main stage',
    'Команда прошла квалификацию и сыграет за призовой фонд в 2 000 000 рублей.': 'The team cleared the qualifier and will play for a 2,000,000-ruble prize pool.',
    'Читать новость': 'Read story',
    '100+ зрителей смотрели наши матчи в пике': '100+ viewers watched our matches at peak',
    '100+ зрителей смотрели матчи GoldRashers в пике.': '100+ viewers watched GoldRashers matches at peak.',
    'Нас становится больше, спасибо каждому, кто смотрит, болеет и следит за нашим путем.': 'Our community is growing. Thank you to everyone who watches, supports us, and follows our journey.',
    'Первый трофей GoldRashers — Лига Будущего 2': 'GoldRashers’ first trophy — League of the Future 2',
    'Забираем чемпионский титул и открываем новую главу в истории организации.': 'We claim the championship title and open a new chapter in the organization’s history.',
    '18 августа 2026': '18 August 2026',
    '19 сентября 2026': '19 September 2026',
    'Все новости': 'All news',
    'Растём.': 'We grow.',
    'Сражаемся.': 'We fight.',
    'Побеждаем.': 'We win.',
    'GoldRashers — быстрорастущая киберспортивная организация, основанная в мае 2026 года, имеющая действующий состав по дисциплине Counter-Strike 2 и создающая собственную экосистему вокруг команды, контента и сообщества.': 'GoldRashers is a fast-growing esports organization founded in May 2026, with an active Counter-Strike 2 roster and its own ecosystem around the team, content, and community.',
    'GoldRashers делает ставку на системный подход, развитие игроков, развитие стаффа и постоянное движение вперёд. Это проект, в котором растут все — как игроки, так и персонал.': 'GoldRashers is built on a structured approach, player and staff development, and constant forward motion. It is a project where everyone grows — players and staff alike.',
    'Организация стремится не просто участвовать в соревнованиях, а создать конкурентоспособный клуб с сильным составом, узнаваемым брендом и собственной историей.': 'The organization aims to do more than compete: it is building a competitive club with a strong roster, a recognizable brand, and its own history.',
    'Клуб регулярно участвует в лигах и турнирах, развивает профессиональный состав, создаёт контент и постепенно расширяет своё присутствие на киберспортивной сцене.': 'The club regularly plays in leagues and tournaments, develops its professional roster, creates content, and steadily expands its esports presence.',
    'Система': 'System',
    'Планомерная подготовка и понятные процессы.': 'Consistent preparation and clear processes.',
    'Развитие': 'Development',
    'Рост игроков, стаффа и клубной экосистемы.': 'Growth for players, staff, and the club ecosystem.',
    'Амбиции': 'Ambition',
    'Узнаваемый бренд и конкурентный результат.': 'A recognizable brand and competitive results.',
    'Строим сильнее': 'Stronger',
    'вместе': 'together',
    'GoldRashers открыт к партнёрствам, которые дают ценность команде, бренду и киберспортивному сообществу.': 'GoldRashers is open to partnerships that bring value to the team, brand, and esports community.',
    'Технологии': 'Technology',
    'Оборудование, сервисы и решения для профессиональной подготовки.': 'Equipment, services, and solutions for professional preparation.',
    'Совместные форматы, турниры, трансляции и бренд-контент.': 'Joint formats, tournaments, broadcasts, and branded content.',
    'Продукты и коллаборации, органично связанные с аудиторией клуба.': 'Products and collaborations that naturally connect with the club’s audience.',
    'Станьте частью следующей победы': 'Be part of the next victory',
    'Связаться в Telegram': 'Contact on Telegram',
    'Игровая джерси': 'Gaming jersey',
    'Скоро': 'Coming soon',
    'Клубное худи': 'Club hoodie',
    'Аксессуары': 'Accessories',
    'Социальные сети GoldRashers': 'GoldRashers social links',
    '© 2026 GoldRashers. Все права защищены.': '© 2026 GoldRashers. All rights reserved.',
    'Все права защищены.': 'All rights reserved.',
    'Наверх': 'Back to top',
    'На главную': 'Home',
    'Все сыгранные матчи GoldRashers по Counter-Strike 2.': 'All completed GoldRashers Counter-Strike 2 matches.',
    'Все матчи — GoldRashers': 'All matches — GoldRashers',
    'Новости — GoldRashers': 'News — GoldRashers',
    'История завершённых встреч GoldRashers в Counter-Strike 2.': 'The history of completed GoldRashers matches in Counter-Strike 2.',
    'Статистика завершённых матчей': 'Completed match statistics',
    'Сыграно': 'Played',
    'Победы': 'Wins',
    'Поражения': 'Losses',
    'Все завершённые матчи GoldRashers': 'All completed GoldRashers matches',
    'Все новости киберспортивной организации GoldRashers.': 'All news from the GoldRashers esports organization.',
    'Турнирные результаты, анонсы матчей и важные события внутри GoldRashers.': 'Tournament results, match announcements, and key events inside GoldRashers.',
    'Архив новостей': 'News archive',
    'Постер GoldRashers в основной стадии CyberClash Open': 'GoldRashers poster for the CyberClash Open main stage',
    'Трансляция матчей GoldRashers': 'GoldRashers match broadcast',
    'Постер победы GoldRashers в Лиге Будущего': 'GoldRashers League of the Future victory poster',
    'GoldRashers в основной стадии CyberClash Open.': 'GoldRashers in the CyberClash Open main stage.',
    'Наши парни прошли квалификацию и примут участие в основной стадии, где 8 команд будут бороться за 2 000 000 рублей.': 'Our team cleared the qualifier and will compete in the main stage, where eight teams will battle for 2,000,000 rubles.',
    'Основная стадия CyberClash Open пройдёт с 26 по 30 августа. Для GoldRashers это возможность закрепить результат квалификации и показать свою игру против сильных соперников.': 'The CyberClash Open main stage runs from 26 to 30 August. It is GoldRashers’ opportunity to build on the qualifier result and show its game against strong opponents.',
    'Результаты квалификации': 'Qualifier results',
    'Спасибо всем, кто следит за командой. Увидимся на матчах основной стадии.': 'Thank you to everyone following the team. See you at the main-stage matches.',
    'Победа в «Лиге Будущего 2» стала первым титулом GoldRashers. Это результат общей работы игроков, тренерского штаба и всей команды за пределами сервера.': 'The League of the Future 2 victory became GoldRashers’ first title. It is the result of the players, coaching staff, and the entire team working together beyond the server.',
    'Мы продолжаем расти, сражаться и ставить перед собой ещё более высокие цели. Впереди новые турниры, новые соперники и новые поводы для побед.': 'We keep growing, fighting, and setting ever-higher goals. New tournaments, new opponents, and new reasons to win are ahead.'
  };

  const sourceText = new WeakMap();
  const sourceAttributes = new WeakMap();
  const sourceTitle = document.title;
  let language = DEFAULT_LANGUAGE;

  const getSavedLanguage = () => {
    try {
      return localStorage.getItem(STORAGE_KEY) === 'en' ? 'en' : DEFAULT_LANGUAGE;
    } catch {
      return DEFAULT_LANGUAGE;
    }
  };

  const translate = (value, targetLanguage = language) => targetLanguage === 'en' ? (translations[value] || value) : value;

  const replaceText = (node) => {
    const original = sourceText.get(node) ?? node.nodeValue;
    sourceText.set(node, original);
    const value = original.trim();
    if (!value) return;
    node.nodeValue = original.replace(value, translate(value));
  };

  const replaceAttribute = (element, attribute) => {
    const saved = sourceAttributes.get(element) || {};
    const original = saved[attribute] ?? element.getAttribute(attribute);
    if (!original) return;
    saved[attribute] = original;
    sourceAttributes.set(element, saved);
    element.setAttribute(attribute, translate(original));
  };

  const updateSwitcher = () => {
    document.querySelectorAll('[data-language]').forEach((button) => {
      const selected = button.dataset.language === language;
      button.classList.toggle('is-active', selected);
      button.setAttribute('aria-pressed', String(selected));
      button.tabIndex = selected ? -1 : 0;
    });
  };

  const applyLanguage = () => {
    document.documentElement.lang = language;
    document.documentElement.dataset.language = language;
    document.title = translate(sourceTitle);
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(replaceText);

    document.querySelectorAll('*').forEach((element) => {
      ['aria-label', 'alt', 'title', 'content'].forEach((attribute) => {
        if (element.hasAttribute(attribute)) replaceAttribute(element, attribute);
      });
    });
    updateSwitcher();
  };

  const setLanguage = (nextLanguage) => {
    language = nextLanguage === 'en' ? 'en' : DEFAULT_LANGUAGE;
    try {
      localStorage.setItem(STORAGE_KEY, language);
    } catch {
      // Language preference is optional when browser storage is unavailable.
    }
    applyLanguage();
    document.dispatchEvent(new CustomEvent('goldrashers:languagechange', { detail: { language } }));
  };

  const createSwitcher = () => {
    if (document.querySelector('.language-switcher')) return;
    const host = document.querySelector('.header-inner');
    if (!host) return;
    const switcher = document.createElement('div');
    switcher.className = 'language-switcher';
    switcher.setAttribute('role', 'group');
    switcher.setAttribute('aria-label', 'Выбор языка');
    switcher.innerHTML = [
      '<button type="button" data-language="ru" aria-label="Русский язык">RU</button>',
      '<button type="button" data-language="en" aria-label="Английский язык">EN</button>'
    ].join('');
    switcher.addEventListener('click', (event) => {
      const button = event.target.closest('[data-language]');
      if (button) setLanguage(button.dataset.language);
    });
    host.append(switcher);
  };

  const initialize = () => {
    language = getSavedLanguage();
    createSwitcher();
    applyLanguage();
    document.dispatchEvent(new CustomEvent('goldrashers:languagechange', { detail: { language } }));
  };

  window.GoldRashersI18n = { get language() { return language; }, setLanguage, translate };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, { once: true });
  } else {
    initialize();
  }
})();
