(() => {
  'use strict';

  const header = document.querySelector('#site-header');
  const menuButton = document.querySelector('.menu-toggle');
  const mobileMenu = document.querySelector('#mobile-menu');
  const mobileLinks = [...document.querySelectorAll('#mobile-menu a[href^="#"]')];
  const navLinks = [...document.querySelectorAll('.desktop-nav a[href^="#"]')];
  const revealItems = [...document.querySelectorAll('.reveal')];
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const localized = (ru, en) => document.documentElement.lang === 'en' ? en : ru;

  const updateHeader = () => {
    header?.classList.toggle('scrolled', window.scrollY > 24);
  };

  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  const closeMenu = ({ restoreFocus = false } = {}) => {
    if (!menuButton || !mobileMenu) return;
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', localized('Открыть меню', 'Open menu'));
    header?.classList.remove('menu-active');
    document.body.classList.remove('menu-open');
    mobileMenu.hidden = true;
    if (restoreFocus) menuButton.focus();
  };

  const openMenu = () => {
    if (!menuButton || !mobileMenu) return;
    mobileMenu.hidden = false;
    menuButton.setAttribute('aria-expanded', 'true');
    menuButton.setAttribute('aria-label', localized('Закрыть меню', 'Close menu'));
    header?.classList.add('menu-active');
    document.body.classList.add('menu-open');
    const firstLink = mobileMenu.querySelector('a');
    window.setTimeout(() => firstLink?.focus(), 30);
  };

  menuButton?.addEventListener('click', () => {
    const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
    isOpen ? closeMenu() : openMenu();
  });

  document.addEventListener('goldrashers:languagechange', () => {
    if (!menuButton) return;
    const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
    menuButton.setAttribute('aria-label', localized(isOpen ? 'Закрыть меню' : 'Открыть меню', isOpen ? 'Close menu' : 'Open menu'));
  });

  mobileLinks.forEach((link) => {
    link.addEventListener('click', () => closeMenu());
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuButton?.getAttribute('aria-expanded') === 'true') {
      closeMenu({ restoreFocus: true });
    }
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 1080 && menuButton?.getAttribute('aria-expanded') === 'true') {
      closeMenu();
    }
  });

  // Reveal content as it enters the viewport.
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    revealItems.forEach((item) => item.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -8% 0px'
    });

    revealItems.forEach((item, index) => {
      item.style.transitionDelay = `${Math.min(index % 5, 4) * 55}ms`;
      revealObserver.observe(item);
    });
  }

  // Highlight the section currently visible in the desktop menu.
  const observedSections = navLinks
    .map((link) => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);

  if ('IntersectionObserver' in window && observedSections.length) {
    const sectionObserver = new IntersectionObserver((entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

      if (!visible) return;
      navLinks.forEach((link) => {
        link.classList.toggle('active', link.getAttribute('href') === `#${visible.target.id}`);
      });
    }, {
      threshold: [0.18, 0.35, 0.55],
      rootMargin: '-18% 0px -58% 0px'
    });

    observedSections.forEach((section) => sectionObserver.observe(section));
  }

  // Count-up animation for selected stats.
  const counters = [...document.querySelectorAll('[data-count]')];
  const formatNumber = (value) => new Intl.NumberFormat(document.documentElement.lang === 'en' ? 'en-US' : 'ru-RU').format(value);

  const animateCounter = (element) => {
    const target = Number(element.dataset.count || 0);
    if (!Number.isFinite(target)) return;

    if (prefersReducedMotion) {
      element.textContent = formatNumber(target);
      return;
    }

    const startTime = performance.now();
    const duration = target > 1000 ? 1150 : 720;

    const frame = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      element.textContent = formatNumber(Math.round(target * eased));
      if (progress < 1) requestAnimationFrame(frame);
    };

    requestAnimationFrame(frame);
  };

  if ('IntersectionObserver' in window) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.65 });

    counters.forEach((counter) => counterObserver.observe(counter));
  } else {
    counters.forEach(animateCounter);
  }

  document.addEventListener('goldrashers:languagechange', () => {
    counters.forEach((counter) => {
      const target = Number(counter.dataset.count || 0);
      if (Number.isFinite(target)) counter.textContent = formatNumber(target);
    });
  });

  const championsDialog = document.querySelector('#league-future-champions');
  const trophyTrigger = document.querySelector('.trophy-card-trigger');
  const championsClose = document.querySelector('.champions-close');

  if (championsDialog && trophyTrigger && championsClose) {
    const closeChampions = () => {
      championsDialog.hidden = true;
      document.body.classList.remove('dialog-open');
      trophyTrigger.focus();
    };

    const openChampions = () => {
      if (!championsDialog.hidden) return;
      championsDialog.hidden = false;
      document.body.classList.add('dialog-open');
      championsClose.focus();
    };

    trophyTrigger.addEventListener('click', openChampions);
    championsClose.addEventListener('click', closeChampions);

    championsDialog.addEventListener('click', (event) => {
      if (event.target === championsDialog) closeChampions();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !championsDialog.hidden) closeChampions();
    });
  }
})();
